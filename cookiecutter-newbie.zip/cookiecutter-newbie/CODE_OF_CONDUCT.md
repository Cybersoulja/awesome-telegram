# Code of Conduct

Everyone interacting in the Cookiecutter project's codebases and documentation is expected to follow the [PyPA Code of Conduct](https://www.pypa.io/en/latest/code-of-conduct/).
This includes, but is not limited to, issue trackers, chat rooms, mailing lists, and other virtual or in real life communication.
